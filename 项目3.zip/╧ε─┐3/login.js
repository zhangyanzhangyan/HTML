function openLogin(){
	document.getElementById("login").style.display="block";
}
function closeLogin(){
	document.getElementById("login").style.display="none";
}
